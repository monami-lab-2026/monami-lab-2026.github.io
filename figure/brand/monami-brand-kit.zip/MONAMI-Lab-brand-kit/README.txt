MONAMI Lab brand kit

Colors
  Navy  #0B2545  (RGB 11, 37, 69)
  Cyan  #00B4D8  (RGB 0, 180, 216)

Files
  monami-logo-primary.png            Stacked logo for light backgrounds
  monami-logo-reversed.png           Stacked logo for dark backgrounds
  monami-logo-white.png              Single-colour white logo
  monami-logo-horizontal.png         Horizontal logo for light backgrounds
  monami-logo-horizontal-reversed.png Horizontal logo for dark backgrounds
  monami-symbol.png                  Symbol only, light backgrounds
  monami-symbol-reversed.png         Symbol only, dark backgrounds

Please keep clear space around the logo, and do not stretch, recolour, or add effects.
